//
//  ListMakerTool.swift
//  ListMaker
//

import ArgumentParser

@main
struct ListMakerTool: AsyncParsableCommand {

    mutating func run() async throws {
        print("Hello, world!")
    }

}
